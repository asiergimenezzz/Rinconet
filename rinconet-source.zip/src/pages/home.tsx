import { motion } from "framer-motion";
import { MapPin, Phone, Clock, Utensils, Users, TreePine, Euro, ArrowRight, Star, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ReservaInline } from "@/components/reserva-inline";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function Home() {
  const mapUrl = "https://www.google.com/maps/dir/?api=1&destination=Av.+de+la+Mare+de+Déu+del+Lledó,+0,+Castellón";
  const phone = "tel:+34964233089";

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary selection:text-white">
      {/* Floating Action Button */}
      <a 
        href={phone}
        className="fixed bottom-6 right-6 z-50 bg-primary text-primary-foreground p-4 rounded-full shadow-xl hover:bg-primary/90 hover:scale-105 transition-all md:hidden flex items-center justify-center"
        aria-label="Llamar ahora"
      >
        <Phone className="w-6 h-6" />
      </a>

      {/* Hero Section */}
      <section className="relative h-[90svh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hero-bg.png" 
            alt="Terraza del Rinconet" 
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-black/40 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>

        <div className="relative z-10 container px-4 mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white mb-6 text-sm font-medium tracking-wide">
              <MapPin className="w-4 h-4" />
              Parque de Rafalafena, Castellón
            </div>
            <h1 className="text-5xl md:text-7xl font-serif text-white font-bold leading-tight mb-6 drop-shadow-lg">
              Disfruta de la cocina mediterránea en plena naturaleza
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-10 font-light drop-shadow-md">
              Comida casera, ambiente familiar y terraza junto al parque en Castellón.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="w-full sm:w-auto text-lg px-8 py-6 rounded-full bg-primary hover:bg-primary/90 text-white shadow-xl hover:shadow-2xl transition-all" asChild>
                <a href="#reservar">
                  <CalendarDays className="w-5 h-5 mr-2" />
                  Reservar mesa
                </a>
              </Button>
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8 py-6 rounded-full bg-white/10 backdrop-blur-md border-white/30 text-white hover:bg-white/20 transition-all" asChild>
                <a href="#carta">Ver carta</a>
              </Button>
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8 py-6 rounded-full bg-white/10 backdrop-blur-md border-white/30 text-white hover:bg-white/20 transition-all" asChild>
                <a href={mapUrl} target="_blank" rel="noopener noreferrer">Cómo llegar</a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Intro / About */}
      <section className="py-24 md:py-32 bg-background relative">
        <div className="container px-4 mx-auto max-w-4xl text-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
          >
            <TreePine className="w-12 h-12 mx-auto text-secondary mb-6 opacity-80" />
            <h2 className="text-3xl md:text-5xl font-serif text-foreground mb-8">El sabor de siempre, donde siempre.</h2>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed font-light">
              Restaurante acogedor situado dentro del Parque de Rafalafena, ideal para familias, grupos y celebraciones. Ambiente tranquilo, terraza junto a zona infantil, trato cercano, cocina tradicional mediterránea.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Differentiators */}
      <section className="py-20 bg-card border-y border-border">
        <div className="container px-4 mx-auto">
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12"
          >
            {[
              { icon: TreePine, title: "Ubicación única", desc: "Dentro del Parque de Rafalafena" },
              { icon: Users, title: "Ideal para familias", desc: "Junto a la zona infantil" },
              { icon: Euro, title: "Precio accesible", desc: "Menú y carta entre 10€ y 20€" },
              { icon: Utensils, title: "Ambiente relajado", desc: "Trato cercano y amable" }
            ].map((feature, i) => (
              <motion.div key={i} variants={fadeIn} className="text-center group">
                <div className="w-16 h-16 mx-auto bg-primary/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-serif font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Visual Break */}
      <section className="h-[60vh] relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/table-spread.png" alt="Tapas y platos mediterráneos" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/20" />
        </div>
        <div className="relative z-10 h-full flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-4xl md:text-6xl font-serif text-white font-bold drop-shadow-xl">Tradición a la mesa</h2>
          </div>
        </div>
      </section>

      {/* Menu / Featured Dishes */}
      <section id="carta" className="py-24 md:py-32 bg-background">
        <div className="container px-4 mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="text-center max-w-2xl mx-auto mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif mb-6">Nuestras Especialidades</h2>
            <p className="text-lg text-muted-foreground">Platos elaborados con cariño, pensados para compartir y disfrutar al aire libre.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {[
              {
                img: "/images/paella.png",
                title: "Paella",
                desc: "Elaborada al estilo tradicional valenciano, con ingredientes frescos y un sabor inconfundible. Perfecta para los domingos al sol."
              },
              {
                img: "/images/carrillada.png",
                title: "Carrillada",
                desc: "Guisada a fuego lento durante horas hasta que se deshace en la boca, acompañada de una reducción intensa y sabrosa."
              },
              {
                img: "/images/croquetas.png",
                title: "Croquetas de jamón",
                desc: "Crujientes por fuera, cremosas por dentro. El bocado que no puede faltar en ninguna mesa."
              },
              {
                img: "/images/bocadillo-lomo.png",
                title: "Bocadillo de lomo, queso y tomate",
                desc: "Un clásico infalible. Pan crujiente, lomo tierno, queso fundido y tomate natural triturado."
              },
              {
                img: "/images/carajillo.png",
                title: "Carajillo de ron",
                desc: "El final perfecto. Café intenso, ron quemado y el equilibrio exacto de dulzor y aroma. Tradición pura de Castellón."
              },
              {
                title: "Bocadillos y Montaditos",
                desc: "Una amplia variedad para almuerzos y cenas informales. Pregunta por nuestras opciones del día.",
                isText: true
              }
            ].map((dish, i) => (
              <motion.div 
                key={i} 
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={fadeIn}
                className="group rounded-2xl overflow-hidden bg-card border border-border shadow-sm hover:shadow-xl transition-all"
              >
                {!dish.isText ? (
                  <>
                    <div className="aspect-[4/3] overflow-hidden">
                      <img src={dish.img} alt={dish.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    </div>
                    <div className="p-6 md:p-8">
                      <h3 className="text-xl font-serif font-bold mb-3">{dish.title}</h3>
                      <p className="text-muted-foreground">{dish.desc}</p>
                    </div>
                  </>
                ) : (
                  <div className="h-full p-8 flex flex-col justify-center bg-accent/20">
                    <h3 className="text-xl font-serif font-bold mb-3">{dish.title}</h3>
                    <p className="text-muted-foreground mb-6">{dish.desc}</p>
                    <h3 className="text-xl font-serif font-bold mb-3">Coca de tomate</h3>
                    <p className="text-muted-foreground">La tradicional coca salada, horneada en su punto ideal.</p>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Reservation flow */}
      <ReservaInline />

      {/* Reviews */}
      <section className="py-24 bg-card">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center mb-12">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex text-amber-500">
                {[1,2,3,4].map(i => <Star key={i} className="w-6 h-6 fill-current" />)}
                <Star className="w-6 h-6 fill-current" strokeWidth={1} style={{ clipPath: "inset(0 50% 0 0)" }} />
              </div>
              <span className="text-2xl font-bold">4,3</span>
            </div>
            <p className="text-muted-foreground">Basado en más de 400 reseñas</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              "Muy rico y los camareros muy atentos",
              "Ideal para ir con niños por su ubicación junto al parque",
              "Ambiente tranquilo y buena comida"
            ].map((quote, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="bg-background p-8 rounded-2xl border border-border text-center shadow-sm relative"
              >
                <div className="text-4xl text-primary/20 font-serif absolute top-4 left-4">"</div>
                <p className="text-lg italic text-foreground relative z-10">"{quote}"</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Location / Practical Info */}
      <section className="py-24 bg-background">
        <div className="container px-4 mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
              className="space-y-8"
            >
              <h2 className="text-4xl md:text-5xl font-serif">Ven a disfrutar de una comida en plena naturaleza</h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-full text-primary shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Dirección</h4>
                    <p className="text-muted-foreground">Av. de la Mare de Déu del Lledó, 0<br/>12003 Castellón de la Plana, Castellón</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-full text-primary shrink-0">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Horario</h4>
                    <p className="text-muted-foreground">Abierto todos los días hasta las 17:00</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-full text-primary shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Teléfono</h4>
                    <a href={phone} className="text-muted-foreground hover:text-primary transition-colors">964 23 30 89</a>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button size="lg" className="rounded-full bg-primary hover:bg-primary/90 text-white w-full sm:w-auto" asChild>
                  <a href={phone}>Llamar ahora</a>
                </Button>
                <Button size="lg" variant="outline" className="rounded-full w-full sm:w-auto" asChild>
                  <a href={mapUrl} target="_blank" rel="noopener noreferrer">Cómo llegar <ArrowRight className="w-4 h-4 ml-2" /></a>
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="h-[400px] lg:h-[500px] rounded-3xl overflow-hidden shadow-xl border border-border"
            >
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3029.0716892694183!2d-0.03366302322304907!3d39.99341497151095!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd5ffe32e92c68ef%3A0xe213b2ceb16d1a93!2sParque%20Rafelafena!5e0!3m2!1sen!2ses!4v1689000000000!5m2!1sen!2ses" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Mapa de ubicación de Rinconet"
              ></iframe>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container px-4 mx-auto text-center">
          <h2 className="text-3xl font-serif font-bold mb-6">Rinconet</h2>
          <p className="text-background/70 mb-8 max-w-md mx-auto">
            El rincón perfecto en el Parque de Rafalafena. Comida casera y trato familiar en Castellón.
          </p>
          <div className="flex items-center justify-center gap-6 mb-12">
            <a href={phone} className="text-background/70 hover:text-white transition-colors">
              <Phone className="w-5 h-5" />
            </a>
            <a href={mapUrl} target="_blank" rel="noopener noreferrer" className="text-background/70 hover:text-white transition-colors">
              <MapPin className="w-5 h-5" />
            </a>
          </div>
          <div className="border-t border-white/10 pt-8 text-sm text-background/50">
            <p>&copy; {new Date().getFullYear()} Rinconet Restaurante. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
