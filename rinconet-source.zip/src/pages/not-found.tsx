import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground">
      <Card className="w-full max-w-md mx-4 border-none shadow-none bg-transparent">
        <CardContent className="pt-6 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center">
              <AlertCircle className="h-10 w-10 text-primary" />
            </div>
          </div>
          
          <h1 className="text-4xl font-serif font-bold mb-4">Página no encontrada</h1>
          
          <p className="text-lg text-muted-foreground mb-8">
            Parece que te has perdido por el parque. No te preocupes, la mesa sigue esperándote.
          </p>

          <Button size="lg" className="rounded-full bg-primary hover:bg-primary/90 text-white" asChild>
            <Link href="/">
              Volver al inicio
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
