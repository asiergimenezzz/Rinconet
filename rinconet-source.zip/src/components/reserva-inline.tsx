import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  Check,
  Clock,
  Mail,
  User,
  Users,
} from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { es } from "date-fns/locale";

const TIMES = [
  "13:00",
  "13:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
];

const PEOPLE_OPTIONS = Array.from({ length: 12 }, (_, i) => i + 1);

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function formatDateLong(d: Date) {
  return d.toLocaleDateString("es-ES", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

type Step = "fecha" | "datos" | "confirmada";

export function ReservaInline() {
  const today = startOfDay(new Date());

  const [step, setStep] = useState<Step>("fecha");
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [people, setPeople] = useState<string>("");
  const [time, setTime] = useState<string>("");
  const [name, setName] = useState<string>("");
  const [email, setEmail] = useState<string>("");

  const isComplete = useMemo(() => {
    return (
      !!date &&
      !!people &&
      !!time &&
      name.trim().length >= 2 &&
      isValidEmail(email)
    );
  }, [date, people, time, name, email]);

  const handleNext = () => {
    if (!date) return;
    setStep("datos");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isComplete) return;
    setStep("confirmada");
  };

  const handleNewReservation = () => {
    setStep("fecha");
    setDate(undefined);
    setPeople("");
    setTime("");
    setName("");
    setEmail("");
  };

  return (
    <section id="reservar" className="py-24 md:py-32 bg-background">
      <div className="container px-4 mx-auto">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
          }}
          className="text-center max-w-2xl mx-auto mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-serif mb-6">
            Reserva tu mesa
          </h2>
          <p className="text-lg text-muted-foreground">
            Elige el día, la hora y déjanos tus datos. Te esperamos en la
            terraza.
          </p>
        </motion.div>

        {/* Stepper */}
        <div className="flex items-center justify-center gap-3 mb-8 text-sm">
          <span
            className={`inline-flex items-center justify-center w-7 h-7 rounded-full font-semibold transition-colors ${
              step === "fecha"
                ? "bg-primary text-primary-foreground"
                : "bg-primary/20 text-primary"
            }`}
          >
            {step === "fecha" ? "1" : <Check className="w-4 h-4" />}
          </span>
          <span
            className={
              step === "fecha"
                ? "font-medium text-foreground"
                : "text-muted-foreground"
            }
          >
            Fecha
          </span>
          <span className="w-10 h-px bg-border" />
          <span
            className={`inline-flex items-center justify-center w-7 h-7 rounded-full font-semibold transition-colors ${
              step === "datos"
                ? "bg-primary text-primary-foreground"
                : step === "confirmada"
                  ? "bg-primary/20 text-primary"
                  : "bg-muted text-muted-foreground"
            }`}
          >
            {step === "confirmada" ? <Check className="w-4 h-4" /> : "2"}
          </span>
          <span
            className={
              step === "datos"
                ? "font-medium text-foreground"
                : "text-muted-foreground"
            }
          >
            Datos
          </span>
        </div>

        <div className="max-w-3xl mx-auto">
          <AnimatePresence mode="wait">
            {step === "fecha" && (
              <motion.div
                key="step-fecha"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35 }}
              >
                <div className="bg-card border border-card-border rounded-3xl shadow-lg p-6 md:p-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-full bg-primary/10 text-primary">
                      <CalendarDays className="w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-serif font-semibold">
                      Selecciona una fecha
                    </h3>
                  </div>

                  <div className="flex justify-center">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      disabled={{ before: today }}
                      locale={es}
                      showOutsideDays={false}
                      className="rounded-2xl bg-background w-full [--cell-size:clamp(2.5rem,9vw,4.5rem)] text-base md:text-lg"
                    />
                  </div>

                  <div className="mt-6 min-h-[2.5rem] text-center">
                    {date ? (
                      <p className="text-base">
                        Fecha seleccionada:{" "}
                        <span className="font-semibold capitalize text-primary">
                          {formatDateLong(date)}
                        </span>
                      </p>
                    ) : (
                      <p className="text-sm text-muted-foreground">
                        Toca un día disponible del calendario para continuar.
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-8 flex justify-end">
                  <Button
                    size="lg"
                    onClick={handleNext}
                    disabled={!date}
                    className="rounded-full px-8 py-6 text-lg bg-primary hover:bg-primary/90 text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Siguiente
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
              </motion.div>
            )}

            {step === "datos" && (
              <motion.div
                key="step-datos"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35 }}
              >
                {date && (
                  <div className="mb-6 flex items-center justify-center">
                    <div className="inline-flex items-center gap-3 px-5 py-3 rounded-full bg-primary/10 text-primary border border-primary/20">
                      <CalendarDays className="w-5 h-5" />
                      <span className="font-medium capitalize">
                        {formatDateLong(date)}
                      </span>
                      <button
                        type="button"
                        onClick={() => setStep("fecha")}
                        className="ml-2 inline-flex items-center gap-1 text-sm text-primary/80 hover:text-primary underline-offset-4 hover:underline"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                        Cambiar
                      </button>
                    </div>
                  </div>
                )}

                <form
                  onSubmit={handleSubmit}
                  className="bg-card border border-card-border rounded-3xl shadow-lg p-6 md:p-10 space-y-6"
                >
                  <div className="space-y-2">
                    <Label htmlFor="people" className="text-base font-medium">
                      <Users className="inline w-4 h-4 mr-2 -mt-0.5 text-primary" />
                      Número de personas
                    </Label>
                    <Select value={people} onValueChange={setPeople}>
                      <SelectTrigger
                        id="people"
                        className="w-full h-12 text-base rounded-xl"
                      >
                        <SelectValue placeholder="¿Cuántos seréis?" />
                      </SelectTrigger>
                      <SelectContent>
                        {PEOPLE_OPTIONS.map((n) => (
                          <SelectItem key={n} value={String(n)}>
                            {n} {n === 1 ? "persona" : "personas"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time" className="text-base font-medium">
                      <Clock className="inline w-4 h-4 mr-2 -mt-0.5 text-primary" />
                      Hora
                    </Label>
                    <Select value={time} onValueChange={setTime}>
                      <SelectTrigger
                        id="time"
                        className="w-full h-12 text-base rounded-xl"
                      >
                        <SelectValue placeholder="Elige una hora" />
                      </SelectTrigger>
                      <SelectContent>
                        {TIMES.map((t) => (
                          <SelectItem key={t} value={t}>
                            {t} h
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-base font-medium">
                      <User className="inline w-4 h-4 mr-2 -mt-0.5 text-primary" />
                      Nombre completo
                    </Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Ej. María García López"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      autoComplete="name"
                      className="h-12 text-base rounded-xl"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-base font-medium">
                      <Mail className="inline w-4 h-4 mr-2 -mt-0.5 text-primary" />
                      Correo electrónico
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="tucorreo@ejemplo.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      autoComplete="email"
                      className="h-12 text-base rounded-xl"
                    />
                  </div>

                  <div className="pt-4">
                    <Button
                      type="submit"
                      size="lg"
                      disabled={!isComplete}
                      className="w-full rounded-full px-8 py-6 text-lg bg-primary hover:bg-primary/90 text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Reservar mesa
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                    {!isComplete && (
                      <p className="mt-3 text-center text-sm text-muted-foreground">
                        Rellena todos los campos para continuar.
                      </p>
                    )}
                  </div>
                </form>
              </motion.div>
            )}

            {step === "confirmada" && (
              <motion.div
                key="step-confirmada"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.45, ease: "easeOut" }}
                className="text-center"
              >
                <div className="bg-card border border-card-border rounded-3xl shadow-xl p-8 md:p-12 max-w-xl mx-auto">
                  <div className="mx-auto w-20 h-20 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-6">
                    <Check className="w-10 h-10" strokeWidth={2.5} />
                  </div>
                  <h3 className="text-3xl md:text-4xl font-serif font-bold mb-4">
                    ¡Mesa reservada!
                  </h3>
                  <p className="text-lg text-muted-foreground mb-8">
                    Hemos recibido tu reserva,{" "}
                    <span className="font-semibold text-foreground">
                      {name.split(" ")[0]}
                    </span>
                    . Te enviaremos la confirmación a{" "}
                    <span className="font-semibold text-foreground">
                      {email}
                    </span>
                    .
                  </p>

                  <div className="bg-background/60 rounded-2xl p-6 text-left space-y-3 mb-8 border border-border">
                    <div className="flex items-center gap-3">
                      <CalendarDays className="w-5 h-5 text-primary shrink-0" />
                      <span className="capitalize">
                        {date ? formatDateLong(date) : ""}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-primary shrink-0" />
                      <span>{time} h</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Users className="w-5 h-5 text-primary shrink-0" />
                      <span>
                        {people}{" "}
                        {Number(people) === 1 ? "persona" : "personas"}
                      </span>
                    </div>
                  </div>

                  <Button
                    onClick={handleNewReservation}
                    size="lg"
                    className="rounded-full bg-primary hover:bg-primary/90 text-white"
                  >
                    Hacer otra reserva
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
